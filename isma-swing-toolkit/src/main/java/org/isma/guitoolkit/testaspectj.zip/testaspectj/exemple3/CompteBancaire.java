package org.isma.guitoolkit.testaspectj.exemple3;

public class CompteBancaire {
	private int solde;

	public CompteBancaire(int solde) {
		this.solde = solde;
	}

	public void depot (int sommeDepot){
		solde = solde + sommeDepot;
	}

	public void retrait (int sommeRetrait){
		solde = solde - sommeRetrait;
	}

	public int getSolde() {
		return solde;
	}

	public void setSolde(int solde) {
		this.solde = solde;
	}
}


