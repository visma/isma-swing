package org.isma.guitoolkit.testaspectj.exemple2;

public class Main {
    public static void main(String[] args) {
        // 1 : Cr�ation d'un compte avec solde initial
        CompteBancaire monCompte = new CompteBancaire(1000);

        // 2 : Retrait
        //System.out.println("AVANT le retrait");

        // 3 : Retrait
        monCompte.retrait(300);

        // 4 : Retrait
        //System.out.println("APRES le retrait");
    }
}


