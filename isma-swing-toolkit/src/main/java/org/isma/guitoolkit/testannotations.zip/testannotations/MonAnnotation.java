package org.isma.guitoolkit.testannotations;

public @interface MonAnnotation {
}
