package org.isma.guitoolkit.testannotations;

public @interface TODO {
}
