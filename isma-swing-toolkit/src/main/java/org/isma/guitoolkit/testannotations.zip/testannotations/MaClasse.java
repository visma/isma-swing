package org.isma.guitoolkit.testannotations;

@MonAnnotation
public class MaClasse {
}
